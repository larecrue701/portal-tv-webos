'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path'),http=require('http');
const {createUploader}=require('./service/upload-manager'),{makeClient}=require('./service/client');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'portal-tv-upload-test-'));
const uploader=createUploader({dir,address:'127.0.0.1'});
async function request(base,route,key,body,origin=base){
 return new Promise((resolve,reject)=>{const q=http.request(base+route,{method:body===undefined?'GET':'POST',headers:{'X-Portal-Key':key||'',Origin:origin,'Content-Type':'application/json','X-Playlist-Name':'Fixture'}},r=>{let data='';r.on('data',b=>data+=b);r.on('end',()=>resolve({status:r.statusCode,data}));});q.on('error',reject);if(body!==undefined)q.write(body);q.end();});
}
(async()=>{
 try{
 const s=await uploader.start(),url=new URL(s.url),base=url.origin,key=url.hash.slice(1);assert.match(key,/^[A-HJ-NP-Z2-9]{5}$/);assert.ok(s.expiresAt>Date.now()+290000&&s.expiresAt<=Date.now()+300000);
 assert.equal((await request(base,'/',null)).status,200);
 assert.equal((await request(base,'/source','wrong','{}')).status,403);
 assert.equal((await request(base,'/source',key,'{}','https://attacker.example')).status,403);
 const profile={kind:'stalker',portal:'https://portal.example/c/',mac:'00:1A:79:12:34:56'};
 assert.equal((await request(base,'/source',key.toLowerCase(),JSON.stringify({name:'Test',profile}))).status,200);
 let taken=uploader.take();assert.equal(taken.items[0].profile.mac,profile.mac);assert.equal(uploader.take().items.length,0);
 assert.equal((await request(base,'/source',key,JSON.stringify({profile:{kind:'m3u',playlist:'http://127.0.0.1/'}}))).status,400);
 const fixture='#EXTM3U\n#EXTINF:-1 group-title="Test",Test Film\nhttps://stream.example/movie.mp4\n';
 const upload=await request(base,'/file',key,fixture);assert.equal(upload.status,200);assert.equal(JSON.parse(upload.data).entries,1);
 const item=uploader.take().items[0];assert.equal(item.profile.kind,'m3u-file');assert.equal(uploader.readFile(item.profile.fileId),fixture);
 assert.equal(fs.statSync(path.join(dir,item.profile.fileId+'.m3u')).mode&0o777,0o600);
 const client=makeClient(undefined,undefined,async()=>{throw Error('Network must not be used');},uploader.readFile);
 const session=await client.dispatch('connect',{profile:item.profile});const list=await client.dispatch('channels',{profile:item.profile,...session});assert.equal(list.channels.length,1);
 assert.equal((await client.dispatch('resolve',{profile:item.profile,cmd:list.channels[0].cmd})).url,'https://stream.example/movie.mp4');
 assert.equal((await request(base,'/file',key,'not m3u')).status,400);
 assert.equal((await request(base,'/file',key,'x'.repeat(2*1024*1024+1))).status,400);
 assert.throws(()=>uploader.readFile('../../private'));
 // Failed origins do not consume attempts; wrong codes are cumulative, even after success.
 assert.equal((await request(base,'/source','ééééé','{}')).status,403);
 assert.equal((await request(base,'/source','AAAAAA','{}')).status,403);
 assert.equal((await request(base,'/source','wrong','{}')).status,403);
 const locked=await request(base,'/source','wrong','{}');assert.equal(locked.status,429);assert.equal(JSON.parse(locked.data).error,'LOCKED');
 assert.equal(uploader.take().locked,true);
 assert.equal((await request(base,'/source',key,JSON.stringify({name:'Blocked',profile}))).status,429,'correct code cannot bypass lockout');
 assert.equal(uploader.take().items.length,0);
 uploader.stop();assert.equal(uploader.active(),false);
 const fresh=new URL((await uploader.start()).url);assert.match(fresh.hash,/^#[A-HJ-NP-Z2-9]{5}$/);assert.equal(uploader.take().locked,false);
 assert.equal((await request(fresh.origin,'/source',fresh.hash.slice(1),JSON.stringify({name:'Restart',profile}))).status,200);
 uploader.stop();
 const restarted=createUploader({dir,address:'127.0.0.1'});assert.equal(restarted.readFile(item.profile.fileId),fixture,'stored file survives service instance');
 restarted.deleteFile(item.profile.fileId);assert.equal(fs.existsSync(path.join(dir,item.profile.fileId+'.m3u')),false);
 console.log('Upload integration passed: 5-character code, case handling, origin, lockout/restart, invalid source, file validation, quota, private permissions, file playback mapping, persistence and removal. No external network.');
 }finally{uploader.stop();fs.rmSync(dir,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});

