"""Build a separate English edition; never rewrite source identifiers or saved data."""
import re, shutil
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/'dist'/'english'
if out.exists(): shutil.rmtree(out)
for folder in ('app','service'): shutil.copytree(root/folder,out/folder)
pairs=[line.split('|',1) for line in (root/'locales/en.txt').read_text().splitlines() if line]
pairs.sort(key=lambda pair:len(pair[0]),reverse=True)
pattern=re.compile('|'.join(r'(?<![A-Za-z0-9_])'+re.escape(a)+r'(?![A-Za-z0-9_])' for a,b in pairs))
mapping=dict(pairs)
for folder in ('app','service'):
 for p in (out/folder).glob('*'):
  if p.suffix not in ('.html','.js'): continue
  s=p.read_text()
  # Only visible text files; protocol/client modules are not translated.
  if p.name not in ('index.html','app.js','remote-select.js','remote-text.js','upload.html','upload.js'): continue
  s=pattern.sub(lambda m:mapping[m[0]],s)
  s=s.replace('lang="fr"','lang="en"')
  p.write_text(s)
print(out)

# Run the same browser regression suite against translated demo fixtures.
test=pattern.sub(lambda m:mapping[m[0]],(root/'test-ui.mjs').read_text())
for a,b in [('lumières','lights'),('Résumé fictif','Fictional demo'),('lien de lecture','playback URL'),('Aucun résumé','No synopsis'),('Reprendre','Resume')]: test=test.replace(a,b)
(out/'test-ui.mjs').write_text(test)
