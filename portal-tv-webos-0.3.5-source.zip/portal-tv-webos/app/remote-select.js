/* Remote-friendly selects: arrows navigate fields; OK opens an explicit chooser. */
(function () {
 'use strict';
 var controls=[],current=null,returnTo=null;
 var dialog=document.createElement('section');dialog.id='selectDialog';dialog.className='modal';dialog.hidden=true;dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');dialog.setAttribute('aria-labelledby','selectTitle');
 dialog.innerHTML='<div class="select-card"><h2 id="selectTitle"></h2><p class="muted">↑ ↓ pour parcourir · OK pour valider · Retour pour annuler</p><div id="selectChoices"></div><button id="selectCancel">Annuler</button></div>';
 document.body.appendChild(dialog);
 var choices=document.getElementById('selectChoices'),cancel=document.getElementById('selectCancel');
 function sync(){controls.forEach(function(c){var option=c.select.options[c.select.selectedIndex];c.button.textContent=(option?option.textContent:'Choisir')+' ▾';c.button.disabled=c.select.disabled;});}
 function close(){dialog.hidden=true;if(returnTo){returnTo.setAttribute('aria-expanded','false');returnTo.focus();}current=null;}
 function open(c){
  if(c.select.disabled)return;current=c.select;returnTo=c.button;sync();choices.textContent='';
  document.getElementById('selectTitle').textContent=c.label;returnTo.setAttribute('aria-expanded','true');
  Array.prototype.forEach.call(current.options,function(option,index){
   var b=document.createElement('button');b.type='button';b.textContent=option.textContent;b.disabled=option.disabled;b.setAttribute('aria-pressed',String(index===current.selectedIndex));
   b.onclick=function(){var target=current;target.selectedIndex=index;close();target.dispatchEvent(new Event('change',{bubbles:true}));sync();};choices.appendChild(b);
  });
  dialog.hidden=false;var selected=choices.children[current.selectedIndex];(selected&&!selected.disabled?selected:cancel).focus();if(selected)selected.scrollIntoView({block:'nearest'});
 }
 Array.prototype.forEach.call(document.querySelectorAll('select'),function(select){
  var label=document.querySelector('label[for="'+select.id+'"]'),b=document.createElement('button');b.id=select.id+'Picker';b.type='button';b.className='select-picker';b.setAttribute('aria-haspopup','dialog');b.setAttribute('aria-expanded','false');
  var c={select:select,button:b,label:label?label.textContent:'Choisir'};controls.push(c);select.hidden=true;select.tabIndex=-1;select.parentNode.insertBefore(b,select.nextSibling);if(label)label.htmlFor=b.id;
  b.onclick=function(){open(c);};select.addEventListener('change',sync);
 });
 cancel.onclick=close;
 document.addEventListener('keydown',function(e){
  var k=e.keyCode;
  if(dialog.hidden){if(k===13||k===32){var c=controls.filter(function(c){return c.button===document.activeElement;})[0];if(c){e.preventDefault();e.stopImmediatePropagation();open(c);}}return;}
  // No key from the chooser reaches catalogue, playback or page-close handlers.
  e.stopImmediatePropagation();e.preventDefault();
  if(k===27||k===461||k===10009){close();return;}
  var buttons=Array.prototype.filter.call(dialog.querySelectorAll('button'),function(b){return !b.disabled;}),index=buttons.indexOf(document.activeElement);
  if(k===13||k===32){if(index>=0)buttons[index].click();return;}
  if(k===38||k===40||k===9){var step=k===38||k===9&&e.shiftKey?-1:1;index=Math.max(0,Math.min(buttons.length-1,index+step));buttons[index].focus();buttons[index].scrollIntoView({block:'nearest'});}
 },true);
 document.addEventListener('visibilitychange',function(){if(document.hidden&&!dialog.hidden)close();});
 window.PortalSelects={sync:sync};sync();
})();
