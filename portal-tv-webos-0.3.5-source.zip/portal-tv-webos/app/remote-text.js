/* Focus is navigation only. OK/click explicitly enters native text editing. */
(function () {
 'use strict';
 var editing=null,swallowEnterUp=false,footer=document.querySelector('footer');
 var normalHint='FLÈCHES pour naviguer · OK pour saisir / choisir · RETOUR pour revenir';
 function isText(n){return n&&n.tagName==='INPUT'&&['text','url','search'].indexOf(n.type)>=0;}
 function hint(){footer.textContent=editing?'SAISIE · OK pour terminer · RETOUR pour quitter la saisie':'FLÈCHES pour naviguer · OK pour saisir / choisir · RETOUR pour revenir';}
 function finish(refocus){
  if(!editing)return;var n=editing;editing=null;n.readOnly=true;n.classList.remove('text-editing');
  n.blur();if(refocus&&n.offsetWidth>0&&!document.hidden)n.focus();hint();
 }
 function begin(n){
  if(n.disabled||n.offsetWidth===0)return;if(editing===n)return;if(editing)finish(false);
  n.blur();editing=n;n.readOnly=false;n.classList.add('text-editing');hint();
  // A fresh editable focus, during the user's OK/click, asks webOS for its keyboard.
  n.focus();
 }
 Array.prototype.forEach.call(document.querySelectorAll('input'),function(n){
  if(!isText(n))return;n.readOnly=true;n.title='OK pour saisir';
  n.addEventListener('click',function(){begin(n);});
  n.addEventListener('blur',function(){if(editing===n){editing=null;n.readOnly=true;n.classList.remove('text-editing');hint();}});
 });
 document.addEventListener('keydown',function(e){
  var n=document.activeElement,k=e.keyCode;if(!isText(n))return;
  if(editing===n){
   // Keep text/caret/keyboard arrows away from page navigation and search shortcuts.
   e.stopImmediatePropagation();
   if(k===13||k===27||k===461||k===10009){e.preventDefault();if(e.repeat)return;swallowEnterUp=k===13;finish(true);}
   return;
  }
  if(k===13){e.preventDefault();e.stopImmediatePropagation();if(e.repeat)return;swallowEnterUp=true;begin(n);}
 },true);
 document.addEventListener('keyup',function(e){if(e.keyCode===13&&swallowEnterUp){swallowEnterUp=false;e.preventDefault();e.stopImmediatePropagation();}},true);
 document.addEventListener('visibilitychange',function(){if(document.hidden)finish(false);});
 footer.textContent=normalHint;
})();
