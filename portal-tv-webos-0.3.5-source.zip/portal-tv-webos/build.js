'use strict';
const fs=require('fs'),path=require('path');
const sharp=require('sharp');
// Generated app assets only. No downloaded artwork or embedded credentials.
const svg=Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256"><rect width="256" height="256" rx="50" fill="#102638"/><rect x="37" y="37" width="182" height="182" rx="35" fill="none" stroke="#71e4cf" stroke-width="8"/><path d="M96 176V79h37c49 0 49 65 0 65H96" fill="none" stroke="#71e4cf" stroke-width="17" stroke-linejoin="round"/></svg>');
Promise.all([sharp(svg).resize(80,80).png().toFile(path.join(__dirname,'app/icon.png')),sharp(svg).resize(130,130).png().toFile(path.join(__dirname,'app/largeIcon.png'))]).then(()=>console.log('Icons generated.')).catch(e=>{console.error(e.message);process.exitCode=1;});
