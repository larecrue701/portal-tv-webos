'use strict';
const fs=require('fs'),path=require('path'),http=require('http'),os=require('os'),crypto=require('crypto');
const {profile,parseM3U}=require('./client');
const MAX=2*1024*1024;
function fail(code){const e=Error(code);e.code=code;return e;}
function createUploader(options={}){
 const dir=options.dir||'/media/internal/.portal-tv-playlists';
 let server=null,key='',origin='',expires=0,timer=null,queue=[],accepted=0,failures=0;
 function storage(){
  fs.mkdirSync(dir,{recursive:true,mode:0o700});
  const stat=fs.lstatSync(dir);if(!stat.isDirectory()||stat.isSymbolicLink()||stat.uid!==process.getuid())throw fail('STORAGE');
  fs.chmodSync(dir,0o700);
 }
 function filePath(id){if(!/^[a-f0-9]{64}$/.test(id||''))throw fail('BAD_PROFILE');return path.join(dir,id+'.m3u');}
 function readFile(id){const p=filePath(id),s=fs.lstatSync(p);if(!s.isFile()||s.isSymbolicLink()||s.size>MAX)throw fail('FILE_UNAVAILABLE');return fs.readFileSync(p,'utf8');}
 function deleteFile(id){const p=filePath(id);if(fs.existsSync(p)){const s=fs.lstatSync(p);if(!s.isFile()||s.isSymbolicLink())throw fail('STORAGE');fs.unlinkSync(p);}return {};}
 function stop(){clearTimeout(timer);if(server){server.close();if(server.closeAllConnections)server.closeAllConnections();server=null;}key='';origin='';expires=0;return {};}
 function address(){if(options.address)return options.address;for(const entries of Object.values(os.networkInterfaces()))for(const a of entries||[])if(a.family==='IPv4'&&!a.internal&&/^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address))return a.address;throw fail('NO_LAN');}
 function state(){return {active:!!server,expiresAt:expires,url:server?origin+'/#'+key:null};}
 async function start(){
  if(server)return state();storage();const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';key=Array.from({length:5},()=>alphabet[crypto.randomInt(alphabet.length)]).join('');accepted=0;failures=0;queue=[];
  const host=address();server=http.createServer(handle);server.maxConnections=4;server.requestTimeout=15000;server.headersTimeout=8000;server.setTimeout(15000,s=>s.destroy());
  try{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,host,resolve);});}catch(_){stop();throw fail('UPLOAD_LISTEN');}
  origin='http://'+host+':'+server.address().port;expires=Date.now()+300000;timer=setTimeout(stop,300000);return state();
 }
 function send(res,status,value,type='application/json'){res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'"});res.end(type==='application/json'?JSON.stringify(value):value);}
 function allowed(req){const supplied=req.headers['x-portal-key'];return typeof supplied==='string'&&/^[A-HJ-NP-Z2-9]{5}$/i.test(supplied)&&key.length===5&&crypto.timingSafeEqual(Buffer.from(supplied.toUpperCase(),'ascii'),Buffer.from(key,'ascii'));}
 function body(req,limit){return new Promise((resolve,reject)=>{let size=0,done=false,chunks=[];req.on('data',c=>{if(done)return;size+=c.length;if(size>limit){done=true;chunks=[];reject(fail('UPLOAD_SIZE'));return;}chunks.push(c);});req.on('end',()=>{if(!done)resolve(Buffer.concat(chunks));});req.on('error',()=>reject(fail('UPLOAD_IO')));});}
 async function handle(req,res){
  try{
   if(req.headers.host!==origin.slice(7))return send(res,403,{error:'HOST'});
   if(req.method==='GET'&&['/','/app.js','/style.css'].includes(req.url)){
    const file=req.url==='/'?'upload.html':req.url==='/app.js'?'upload.js':'upload.css';
    return send(res,200,fs.readFileSync(path.join(__dirname,file)),req.url==='/'?'text/html; charset=utf-8':req.url==='/app.js'?'text/javascript; charset=utf-8':'text/css; charset=utf-8');
   }
   if(req.method!=='POST'||req.headers.origin!==origin)return send(res,403,{error:'ORIGIN'});
   if(!['/source','/file'].includes(req.url))return send(res,404,{error:'NOT_FOUND'});
   if(failures>=5)return send(res,429,{error:'LOCKED'});
   if(!allowed(req)){failures++;return send(res,failures>=5?429:403,{error:failures>=5?'LOCKED':'ACCESS'});}
   if(accepted>=10||queue.length>=5)return send(res,429,{error:'UPLOAD_LIMIT'});
   let item;
   if(req.url==='/source'){
    let p;try{p=JSON.parse((await body(req,16000)).toString('utf8'));}catch(e){throw e.code?e:fail('BAD_PROFILE');}
    if(p.profile&&p.profile.kind==='m3u-file')throw fail('BAD_PROFILE');
    const validated=profile(p.profile);
    item={name:String(p.name||'Ma source').trim().slice(0,60)||'Ma source',profile:validated};
   }else{
    const raw=await body(req,MAX),text=raw.toString('utf8').replace(/^\uFEFF/,'');
    const parsed=parseM3U(text,'https://invalid.local/');storage();
    const fileId=crypto.createHash('sha256').update(text).digest('hex'),target=filePath(fileId);
    const files=fs.readdirSync(dir).filter(n=>/^[a-f0-9]{64}\.m3u$/.test(n));
    if(files.length>=20&&!fs.existsSync(target))throw fail('FILE_LIMIT');
    if(!fs.existsSync(target))fs.writeFileSync(target,text,{mode:0o600,flag:'wx'});
    let name='Playlist importée';try{name=decodeURIComponent(req.headers['x-playlist-name']||name);}catch(_){}
    item={name:name.replace(/[\/\\]/g,' ').replace(/\.m3u8?$/i,'').slice(0,60),profile:{kind:'m3u-file',fileId},entries:parsed.rows.length,skipped:parsed.skipped};
   }
   queue.push(item);accepted++;send(res,200,{ok:true,entries:item.entries,skipped:item.skipped});
  }catch(e){send(res,400,{error:/^[A-Z_]+$/.test(e.code||'')?e.code:'UPLOAD_IO'});}
 }
 return {start,stop,active:()=>!!server,take:()=>({active:!!server,locked:failures>=5,items:queue.splice(0)}),readFile,deleteFile};
}
module.exports={createUploader};

