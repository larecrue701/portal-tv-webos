'use strict';
const key=location.hash.slice(1).toUpperCase();history.replaceState(null,'',location.pathname);
const el=id=>document.getElementById(id);
el('kind').onchange=()=>{el('stalker').hidden=el('kind').value!=='stalker';el('urlFields').hidden=el('kind').value!=='m3u';el('fileFields').hidden=el('kind').value!=='file';};
if(!/^[A-HJ-NP-Z2-9]{5}$/.test(key)){el('submit').disabled=true;el('status').textContent='Ouvrez le lien complet affiché sur la TV, y compris son code de 5 caractères après #.';}
el('form').onsubmit=async event=>{event.preventDefault();el('submit').disabled=true;el('status').textContent='Envoi local en cours…';try{
 const headers={'X-Portal-Key':key};let body,route;
 if(el('kind').value==='file'){const f=el('file').files[0];if(!f)throw Error('Choisissez un fichier M3U.');if(f.size>2*1024*1024)throw Error('Ce fichier dépasse la limite de 2 Mo.');headers['Content-Type']='application/octet-stream';headers['X-Playlist-Name']=encodeURIComponent(el('name').value||f.name);body=f;route='/file';}
 else{let profile;if(el('kind').value==='m3u')profile={kind:'m3u',playlist:el('playlist').value.trim()};else{profile={kind:'stalker'};for(const id of ['portal','mac','model','serial','deviceId','deviceId2'])profile[id]=el(id).value.trim();}body=JSON.stringify({name:el('name').value.trim(),profile});headers['Content-Type']='application/json';route='/source';}
 const response=await fetch(route,{method:'POST',headers,body,credentials:'omit'});const result=await response.json();
 if(result.error==='LOCKED')throw Error('Lien bloqué après 5 codes incorrects. Fermez puis rouvrez le lien sur la TV.');
 if(!response.ok){const messages={ACCESS:'Lien invalide ou expiré. Rouvrez « Ajouter depuis le Mac » sur la TV.',BAD_MAC:'Format MAC invalide.',BAD_URL:'Adresse HTTP(S) invalide.',BAD_PLAYLIST:'Le fichier n’est pas un catalogue M3U valide.',EMPTY_PLAYLIST:'Aucun flux HTTP(S) utilisable.',UPLOAD_SIZE:'Fichier trop volumineux (2 Mo maximum).',TOO_LARGE:'La liste dépasse 10 000 éléments ou 500 bouquets.',UPLOAD_LIMIT:'Trop d’envois : consultez la TV puis rouvrez le lien.',FILE_LIMIT:'20 fichiers maximum : supprimez une ancienne source.'};throw Error(messages[result.error]||'Envoi refusé ('+result.error+').');}
 el('status').textContent='Envoyé. Vérifiez son apparition dans « Mes sources » sur la TV.'+(result.entries!==undefined?'\n'+result.entries+' éléments importés'+(result.skipped?' · '+result.skipped+' ignorés':'')+'.':'');
 }catch(error){el('status').textContent=error.message==='Failed to fetch'?'Connexion perdue ou lien expiré. Rouvrez le lien depuis la TV.':error.message;}finally{el('submit').disabled=false;}};
