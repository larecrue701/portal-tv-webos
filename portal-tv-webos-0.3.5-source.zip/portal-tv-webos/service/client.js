'use strict';
// Independent minimal Stalker client. No shell, disk writes, arbitrary RPC or listener.
const http = require('http'), https = require('https'), dns = require('dns'), net = require('net');
const {URL} = require('url');
const crypto = require('crypto');
function fail(code) { const e = Error(code); e.code = code; return e; }
function isPublic(address) {
  if (net.isIP(address) !== 4) return false; // IPv4-only MVP, including DNS pinning.
  const p = address.split('.').map(Number);
  return !(p[0]===0 || p[0]===10 || p[0]===127 || p[0]>=224 ||
    p[0]===169&&p[1]===254 || p[0]===172&&p[1]>=16&&p[1]<=31 ||
    p[0]===192&&(p[1]===168 || p[1]===0 || p[1]===2) ||
    p[0]===100&&p[1]>=64&&p[1]<=127 || p[0]===198&&(p[1]===18||p[1]===19||p[1]===51) ||
    p[0]===203&&p[1]===0&&p[2]===113);
}
function parseURL(raw) {
  if (typeof raw !== 'string' || raw.length>4096 || /[\s\x00-\x1f\x7f]/.test(raw)) throw fail('BAD_URL');
  let u; try {u = new URL(raw);} catch (_) {throw fail('BAD_URL');}
  if (!['http:','https:'].includes(u.protocol)||u.username||u.password||u.hash) throw fail('BAD_URL');
  if (u.hostname==='localhost'||u.hostname.endsWith('.localhost')||u.hostname.endsWith('.local')||u.hostname.includes(':')) throw fail('PRIVATE_HOST');
  if(net.isIP(u.hostname) && !isPublic(u.hostname)) throw fail('PRIVATE_HOST');
  return u;
}
function profile(raw) {
  if(!raw||typeof raw!=='object')throw fail('BAD_PROFILE');
  if(raw.kind==='m3u-file'){if(!/^[a-f0-9]{64}$/.test(raw.fileId||''))throw fail('BAD_PROFILE');return {kind:'m3u-file',fileId:raw.fileId};}
  if(raw.kind==='m3u')return {kind:'m3u',playlist:parseURL(String(raw.playlist||'').trim()).href};
  if(raw.kind&&raw.kind!=='stalker')throw fail('BAD_PROFILE');
  const u=parseURL(String(raw.portal||'').trim());
  if(u.search)throw fail('BAD_URL');
  const mac=String(raw.mac||'').trim().toUpperCase();
  if(!/^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$/.test(mac))throw fail('BAD_MAC');
  const model=raw.model||'MAG250';
  if(!['MAG250','MAG322'].includes(model))throw fail('BAD_MODEL');
  const p={portal:u.href,mac,model,serial:'',deviceId:'',deviceId2:''};
  for(const key of ['serial','deviceId','deviceId2']) {
    p[key]=String(raw[key]||'').trim();
    if(!/^[a-zA-Z0-9_-]{0,128}$/.test(p[key]))throw fail('BAD_ID');
  }
  return p;
}
function endpoints(p) {
  const u=new URL(p.portal);
  if(/\/(?:portal|load)\.php$/.test(u.pathname))return [u.href];
  let base=u.pathname.replace(/\/index\.html?$/,'').replace(/\/c\/?$/,'').replace(/\/$/,'');
  const out=[u.origin+base+'/server/load.php',u.origin+base+'/portal.php'];
  if(!base)out.push(u.origin+'/stalker_portal/server/load.php');
  return Array.from(new Set(out));
}
function headers(p, token, endpoint) {
  const u=new URL(endpoint), base=u.pathname.replace(/\/(?:server\/load|portal)\.php$/,'');
  const h={Accept:'application/json', 'Accept-Encoding':'identity',
    'User-Agent':'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
    'X-User-Agent':'Model: '+p.model+'; Link: WiFi',
    Cookie:'mac='+encodeURIComponent(p.mac)+'; stb_lang=fr; timezone=Europe%2FParis',
    Referer:u.origin+base+'/c/'};
  if(token)h.Authorization='Bearer '+token;
  return h;
}
// Resolve IPv4 once per connection and pin the checked address. Redirects must
// remain on the same origin, so portal MAC/token headers never leak to a new host.
function requestJSON(address, h, textMode=false) {
  const original=parseURL(address);
  return new Promise((resolve,reject)=>{
    let finished=false,active=null;
    const timer=setTimeout(()=>finish(fail('TIMEOUT')),10000);
    function finish(e,result){if(finished)return;finished=true;clearTimeout(timer);if(e&&active)active.destroy();e?reject(e):resolve(result);}
    function fetchAt(u,depth) {
      const transport=u.protocol==='https:'?https:http;
      active=transport.get(u,{headers:h,lookup:(host,opts,cb)=>{
        dns.lookup(host,{family:4},(e,ip)=>{if(e)return cb(fail('DNS'));if(!isPublic(ip))return cb(fail('PRIVATE_HOST'));cb(null,ip,4);});
      }},res=>{
        if(finished){res.destroy();return;}
        if([301,302,303,307,308].includes(res.statusCode)) {
          res.resume();let next;
          try {next=parseURL(new URL(res.headers.location,u).href);}catch(_){return finish(fail('REDIRECT'));}
          if(depth>=2||next.origin!==original.origin)return finish(fail('REDIRECT'));
          return fetchAt(next,depth+1);
        }
        if(res.statusCode!==200){res.resume();return finish(fail(res.statusCode===429?'RATE_LIMIT':res.statusCode===401||res.statusCode===403?'AUTH':res.statusCode===404?'NOT_FOUND':'HTTP_ERROR'));}
        if(res.headers['content-encoding']&&res.headers['content-encoding']!=='identity'){res.resume();return finish(fail('ENCODING'));}
        let size=0;const chunks=[];
        res.on('data',b=>{size+=b.length;if(size>2*1024*1024){finish(fail('TOO_LARGE'));res.destroy();}else chunks.push(b);});
        res.on('aborted',()=>finish(fail('NETWORK')));
        res.on('error',()=>finish(fail('NETWORK')));
        res.on('end',()=>{if(finished)return;try{const body=Buffer.concat(chunks).toString('utf8').replace(/^\uFEFF/,'');if(textMode)return finish(null,body);const j=JSON.parse(body);if(!j||!Object.prototype.hasOwnProperty.call(j,'js'))throw Error();finish(null,j.js);}catch(_){finish(fail('BAD_RESPONSE'));}});
      });
      active.on('error',e=>finish(fail(['PRIVATE_HOST','DNS'].includes(e.code)?e.code:'NETWORK')));
    }
    fetchAt(original,0);
  });
}
function tokenValue(value){if(typeof value!=='string'||!value||value.length>2048||!/^[A-Za-z0-9._~+\/=:-]+$/.test(value))throw fail('AUTH');return value;}
function extractStream(command){
  if(typeof command!=='string'||command.length>4096)throw fail('BAD_STREAM');
  // Parse a known media prefix as data only; never run portal commands.
  const raw=command.replace(/^(?:ffmpeg|ffrt|auto)\s+/, '').trim();
  if(!/^https?:\/\/\S+$/.test(raw))throw fail('UNSUPPORTED_STREAM');
  return parseURL(raw).href;
}
function parseM3U(body,base){
  if(typeof body!=='string'||!/^\s*#EXTM3U\b/.test(body)||/^#EXT-X-/m.test(body))throw fail('BAD_PLAYLIST');
  const rows=[],groups=new Map();let info=null,group='',skipped=0;
  for(const raw of body.split(/\r?\n/)){
    const line=raw.trim();if(!line)continue;
    if(line.startsWith('#EXTINF:')){
      const match=line.match(/,(?=(?:[^"]*"[^"]*")*[^"]*$)/);
      const attr=line.match(/\bgroup-title="([^"]*)"/i);
      info={name:match?line.slice(match.index+1).trim().slice(0,160):'',group:attr?attr[1].slice(0,160):''};group='';continue;
    }
    if(line.startsWith('#EXTGRP:')){group=line.slice(8).trim().slice(0,160);continue;}
    if(line[0]==='#')continue;
    try{
      const url=parseURL(new URL(line,base).href).href;
      const name=info&&info.name||'Élément '+(rows.length+1),title=info&&info.group||group||'Sans bouquet';
      const genre=crypto.createHash('sha256').update(title).digest('hex').slice(0,24);
      groups.set(genre,title);const id=String(rows.length+1);
      rows.push({id,name,number:id,cmd:id,genre,url,description:''});
      if(rows.length>10000||groups.size>500)throw fail('TOO_LARGE');
    }catch(e){if(e.code==='TOO_LARGE')throw e;skipped++;}
    info=null;group='';
  }
  if(!rows.length)throw fail('EMPTY_PLAYLIST');
  return {rows,categories:Array.from(groups,([id,name])=>({id,name})),skipped};
}
function makeClient(transport=requestJSON,wait=ms=>new Promise(r=>setTimeout(r,ms)),playlistTransport=address=>requestJSON(address,{'Accept-Encoding':'identity'},true),fileLoader=()=>{throw fail('FILE_UNAVAILABLE');}) {
  function searchTerm(value){if(value===undefined)return '';if(typeof value!=='string'||value.length>120||/[\x00-\x1f\x7f]/.test(value))throw fail('BAD_SEARCH');return value.trim();}
  const playlists=new Map();
  async function playlist(p,alive){
    const key=p.kind==='m3u-file'?'file:'+p.fileId:p.playlist;
    const old=playlists.get(key);if(old&&Date.now()-old.at<300000)return old.data;
    if(!alive())throw fail('CANCELLED');const body=p.kind==='m3u-file'?await fileLoader(p.fileId):await playlistTransport(p.playlist);if(!alive())throw fail('CANCELLED');
    if(Buffer.byteLength(body,'utf8')>2*1024*1024)throw fail('TOO_LARGE');
    const data=parseM3U(body,p.playlist||'https://invalid.local/');if(playlists.size>=2)playlists.delete(playlists.keys().next().value);
    playlists.set(key,{at:Date.now(),data});return data;
  }
  async function rawCall(p,endpoint,token,type,action,extra) {
    const u=new URL(endpoint);u.search=new URLSearchParams(Object.assign({type,action,JsHttpRequest:'1-xml'},extra||{})).toString();
    return transport(u.href,headers(p,token,endpoint));
  }
  async function dispatch(method,payload,alive=()=>true){
    async function call(...args){if(!alive())throw fail('CANCELLED');const result=await rawCall(...args);if(!alive())throw fail('CANCELLED');return result;}
    const p=profile(payload.profile);
    if(p.kind==='m3u'||p.kind==='m3u-file'){
      if(!['connect','categories','channels','resolve'].includes(method))throw fail('BAD_METHOD');
      if(payload.media&&payload.media!=='itv')throw fail('BAD_MEDIA');
      const data=await playlist(p,alive);
      if(method==='connect')return {endpoint:p.playlist||'file:'+p.fileId,token:'m3u',profileKey:crypto.createHash('sha256').update(p.playlist||'file:'+p.fileId).digest('hex'),skipped:data.skipped};
      if(method==='categories')return {categories:data.categories};
      if(method==='channels'){
        const page=Number(payload.page||1),category=String(payload.category||'*');
        if(!Number.isInteger(page)||page<1||page>10000||!/^[-\w*]{1,80}$/.test(category))throw fail('BAD_PAGE');
        const fold=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
        const search=fold(searchTerm(payload.search));
        const rows=data.rows.filter(x=>(category==='*'||x.genre===category)&&(!search||fold(x.name).includes(search)));
        return {page,total:rows.length,pageSize:30,channels:rows.slice((page-1)*30,page*30).map(({url,genre,...row})=>row)};
      }
      const row=data.rows.find(x=>x.cmd===payload.cmd);if(!row)throw fail('BAD_STREAM');return {url:row.url};
    }
    const options=endpoints(p);
    if(method==='connect') {
      let selected=null,token=null,last='NOT_FOUND';
      for(const endpoint of options){
        try {const j=await call(p,endpoint,null,'stb','handshake',{token:''});token=tokenValue(j&&j.token);selected=endpoint;break;}
        catch(e){last=e.code||'NETWORK';if(!['NOT_FOUND','BAD_RESPONSE'].includes(last))throw fail(last);await wait(400);}
      }
      if(!selected)throw fail(last);
      await wait(400);
      const serial=p.serial||crypto.createHash('md5').update(p.mac).digest('hex').slice(0,13).toUpperCase();
      const j=await call(p,selected,token,'stb','get_profile',{hd:'1',stb_type:p.model,client_type:'STB',sn:serial,
        device_id:p.deviceId,device_id2:p.deviceId2||p.deviceId,auth_second_step:'0',not_valid_token:'0',video_out:'hdmi',
        ver:'ImageDescription: 0.2.18-r23-250; PORTAL version: 5.6.2; API Version: JS API version: 343; STB API version: 146;',
        timestamp:String(Math.floor(Date.now()/1000))});
      if(!j||typeof j!=='object'||j.blocked===true||j.blocked===1||j.blocked==='1'||j.status===1||j.status==='1')throw fail('DEVICE_BLOCKED');
      return {endpoint:selected,token,profileKey:crypto.createHash('sha256').update(selected+'\n'+p.mac).digest('hex')};
    }
    if(!['categories','channels','resolve'].includes(method))throw fail('BAD_METHOD');
    if(!options.includes(payload.endpoint))throw fail('BAD_ENDPOINT');
    const token=tokenValue(payload.token);
    const media=payload.media||'itv';
    if(!['itv','vod'].includes(media))throw fail('BAD_MEDIA');
    if(method==='categories'){
      const j=await call(p,payload.endpoint,token,media,media==='vod'?'get_categories':'get_genres');
      if(!Array.isArray(j))throw fail(j===false?'AUTH':'BAD_RESPONSE');
      return {categories:j.slice(0,500).map(x=>({id:String(x.id).slice(0,80),name:String(x.title||x.name||x.id).slice(0,160)}))};
    }
    if(method==='channels'){
      const page=Number(payload.page||1),category=String(payload.category||'*');
      if(!Number.isInteger(page)||page<1||page>10000||!/^[-\w*]{1,80}$/.test(category))throw fail('BAD_PAGE');
      const query=media==='vod'?{category:category,p:page,sortby:'added',fav:'0'}:{genre:category,p:page,sortby:'number',fav:'0',hd:'0',from_ch_id:'0'};
      const search=searchTerm(payload.search);if(search)query.search=search;
      const j=await call(p,payload.endpoint,token,media,'get_ordered_list',query);
      if(!j||!Array.isArray(j.data))throw fail(j===false?'AUTH':'BAD_RESPONSE');
      if(j.data.length>100)throw fail('TOO_LARGE');
      const rows=j.data;
      return {page,total:Math.max(0,Number(j.total_items)||0),pageSize:Math.max(1,Number(j.max_page_items)||rows.length||1),
        channels:rows.map(x=>({id:String(x.id).slice(0,80),name:String(x.name||x.title||x.id).slice(0,160),number:media==='vod'?'':String(x.number||'').slice(0,12),cmd:String(x.cmd||'').slice(0,4096),description:media==='vod'?String(x.description||x.plot||'').slice(0,4000):'',year:media==='vod'?String(x.year||'').slice(0,40):'',director:media==='vod'?String(x.director||'').slice(0,160):'',actors:media==='vod'?String(x.actors||'').slice(0,400):''}))};
    }
    if(typeof payload.cmd!=='string'||payload.cmd.length>4096||/[\r\n\x00]/.test(payload.cmd))throw fail('BAD_STREAM');
    const j=await call(p,payload.endpoint,token,media,'create_link',{cmd:payload.cmd,series:'',forced_storage:'0',disable_ad:'0',download:'0'});
    if(!j||typeof j.cmd!=='string')throw fail(j===false?'AUTH':'BAD_STREAM');
    return {url:extractStream(j.cmd)};
  }
  return {dispatch};
}
module.exports={makeClient,profile,endpoints,isPublic,parseURL,extractStream,requestJSON,parseM3U};
