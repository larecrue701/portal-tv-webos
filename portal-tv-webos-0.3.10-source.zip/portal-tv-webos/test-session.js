'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const app=fs.readFileSync(__dirname+'/app/app.js','utf8');
const code=app.slice(app.indexOf('var renewal=null;'),app.indexOf('function work('));
async function scenario(error,kind='stalker',permanent=false,cancel=false){
 const calls=[],s={profile:{kind},endpoint:'old',token:'old'};
 const ctx={session:s,epoch:0,rawRpc:async(method,payload)=>{
  calls.push({method,payload});
  if(method==='connect'){if(cancel)ctx.epoch++;return {endpoint:'new',token:'fresh'};}
  if(calls.length===1||permanent)throw {code:error};
  return {url:'https://example.com/video'};
 }};
 vm.createContext(ctx);vm.runInContext(code,ctx);
 let result,failure;try{result=await ctx.rpc('resolve',{profile:s.profile,endpoint:s.endpoint,token:s.token,cmd:'channel2',media:'itv'});}catch(e){failure=e;}
 return {calls,result,failure};
}
(async()=>{
 for(const error of ['AUTH','BAD_RESPONSE','BAD_STREAM']){
  const r=await scenario(error);assert.equal(r.calls.length,3);assert.equal(r.result.url,'https://example.com/video');assert.equal(r.calls[2].payload.token,'fresh');assert.equal(r.calls[2].payload.cmd,'channel2');
  const bad=await scenario(error,'stalker',true);assert.equal(bad.calls.length,3);assert.equal(bad.failure.code,error);
 }
 for(const error of ['TIMEOUT','NETWORK','RATE_LIMIT','DEVICE_BLOCKED'])assert.equal((await scenario(error)).calls.length,1);
 assert.equal((await scenario('BAD_RESPONSE','m3u')).calls.length,1);
 const cancelled=await scenario('AUTH','stalker',false,true);assert.equal(cancelled.failure.code,'CANCELLED');assert.equal(cancelled.calls.length,2);
 console.log('Session recovery: renewed token, preserved channel, bounded retries, M3U exclusion and cancellation passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
