const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const s=fs.readFileSync(__dirname+'/app/app.js','utf8');
let now=30000,requests=0,reloads=0,complete;
const video={currentTime:0,paused:true,ended:false};
const ctx={Date:{now:()=>now},document:{hidden:false,body:{classList:{contains:()=>true}},addEventListener:()=>{}},setInterval:()=>{},media:'itv',currentURL:'old',busy:false,epoch:0,playingKey:'channel',playingButton:null,el:()=>video,args:x=>x,rpc:()=>{requests++;return new Promise(r=>complete=r);},source:()=>{reloads++;ctx.liveSerial++;ctx.liveChannel=null;},rememberPlaying:()=>{},enterFullscreen:()=>{},notice:()=>{},errorMessage:()=>''};
vm.createContext(ctx);vm.runInContext(s.slice(s.indexOf('var liveSerial='),s.indexOf('function stop(){')),ctx);
(async()=>{
 ctx.liveChannel={cmd:'demo'};ctx.manualPause=true;ctx.checkLive();assert.equal(requests,0);
 ctx.manualPause=false;ctx.media='vod';ctx.checkLive();assert.equal(requests,0);
 ctx.media='itv';ctx.liveProgress=now;ctx.checkLive();assert.equal(requests,0);ctx.checkLive(true);ctx.checkLive(true);assert.equal(requests,1);complete({url:'new'});await new Promise(setImmediate);assert.equal(reloads,1);
 now+=30000;ctx.checkLive();ctx.liveSerial++;complete({url:'stale'});await new Promise(setImmediate);assert.equal(reloads,1);
 now+=30000;ctx.checkLive();assert.equal(requests,2,'bounded retries');
 video.currentTime=3;video.paused=false;ctx.checkLive();assert.equal(ctx.liveAttempts,0,'progress restores retry budget');
 console.log('Live recovery: pause/VOD exclusions, single in-flight request, stale response cancellation and retry limit passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
