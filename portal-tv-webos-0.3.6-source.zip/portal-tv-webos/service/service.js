'use strict';
const palmbus=require('/usr/lib/nodejs/palmbus');
const uploads=require('./upload-manager').createUploader();
const client=require('./client').makeClient(undefined,undefined,undefined,uploads.readFile);
const ID='org.portaltv.player.service',APP='org.portaltv.player';
const handle=new palmbus.Handle(ID);
let busy=false,idle;const live=new Set();
function arm(){clearTimeout(idle);idle=setTimeout(()=>{if(uploads.active()){arm();return;}handle.unregister();process.exit(0);},15000);}
handle.on('cancel',message=>live.delete(message.uniqueToken()));
handle.on('request',async message=>{
  const reply=value=>{try{message.respond(JSON.stringify(value));}catch(_){}};
  const caller=message.applicationID();
  if(typeof caller!=='string'||caller.split(' ')[0]!==APP)return reply({returnValue:false,errorCode:'CALLER'});
  if(message.payload().length>20000||message.isSubscription())return reply({returnValue:false,errorCode:'BAD_REQUEST'});
  const method=message.method();
  if(method==='ping'){reply({returnValue:true,version:'0.3.6',uid:process.getuid(),node:process.version});if(!busy)arm();return;}
  if(['uploadStart','uploadTake','uploadStop','deleteFile'].includes(method)){
    try{const payload=JSON.parse(message.payload());const result=method==='uploadStart'?await uploads.start():method==='uploadTake'?uploads.take():method==='uploadStop'?uploads.stop():uploads.deleteFile(payload.fileId);reply(Object.assign({returnValue:true},result));}
    catch(e){reply({returnValue:false,errorCode:/^[A-Z_]+$/.test(e.code||'')?e.code:'UPLOAD_IO'});}if(!busy)arm();return;
  }
  if(busy)return reply({returnValue:false,errorCode:'BUSY'});
  busy=true;clearTimeout(idle);const key=message.uniqueToken();live.add(key);
  try {const result=await client.dispatch(method,JSON.parse(message.payload()),()=>live.has(key));reply(Object.assign({returnValue:true},result));}
  catch(e){reply({returnValue:false,errorCode:/^[A-Z_]+$/.test(e.code||'')?e.code:'INTERNAL'});}
  finally{live.delete(key);busy=false;arm();}
});
['ping','connect','categories','channels','resolve','uploadStart','uploadTake','uploadStop','deleteFile'].forEach(method=>handle.registerMethod('/',method));
arm();
